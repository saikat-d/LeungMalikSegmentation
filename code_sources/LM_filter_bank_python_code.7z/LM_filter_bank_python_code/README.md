# LM_filter_bank_python_code
Python code for generating Leung-Malik (LM) filter bank that is typically used in texture analysis and classification.

## Filter Bank:
![screenshot](https://github.com/CVDLBOT/LM_filter_bank_python_code/blob/master/lmfilters.jpg)
